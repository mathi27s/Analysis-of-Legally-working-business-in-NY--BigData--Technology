package gendata;

import java.io.*; 
import java.util.*;
import java.util.Map.Entry;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable; 
import org.apache.hadoop.mapreduce.Mapper; 
  
public class top20Mapper extends Mapper<LongWritable, Text, Text, IntWritable> { 
  

  
    @Override
    public void map(LongWritable key, Text value, Context context) throws 
    IOException, InterruptedException{
    { 
  
      
        // we split the input data 
        String tokens = value.toString(); 
       System.out.println(tokens.split(",")[2]);
     
        String field2 = tokens.split(",")[2]; 
        context.write(new Text(field2), new IntWritable(1));	

    }
  
    
        } 
    } 
